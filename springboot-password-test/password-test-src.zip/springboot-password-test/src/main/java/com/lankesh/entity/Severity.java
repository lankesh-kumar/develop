/**
 * 
 */
package com.lankesh.entity;

/**
 * @author Lankesh Kumar
 *
 */
public enum Severity {

	ERROR, WARNING, INFO
}
